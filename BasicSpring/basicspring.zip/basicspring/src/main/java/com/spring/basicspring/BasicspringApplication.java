package com.spring.basicspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasicspringApplication {

	public static void main(String[] args) {
		SpringApplication.run(BasicspringApplication.class, args);
	}

}
