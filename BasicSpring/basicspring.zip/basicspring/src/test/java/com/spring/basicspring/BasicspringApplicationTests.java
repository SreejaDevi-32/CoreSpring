package com.spring.basicspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasicspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
